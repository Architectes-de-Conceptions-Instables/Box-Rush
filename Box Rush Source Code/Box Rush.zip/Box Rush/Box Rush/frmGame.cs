﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using WMPLib;
using System.Threading.Tasks;

namespace Box_Rush
{
    public partial class frmGame : Form
    {

        public frmGame()
        {
            InitializeComponent();
            Cursor.Hide();
            this.Load += frmGame_Load;
        }

        private void axWindowsMediaPlayer1_PlayStateChange(object sender, AxWMPLib._WMPOCXEvents_PlayStateChangeEvent e)
        {
            if (e.newState == (int)WMPLib.WMPPlayState.wmppsPaused)
            {
                axWindowsMediaPlayer1.Ctlcontrols.play();
            }
        }

        private async void frmGame_Load(object sender, EventArgs e)
        {
            SetFullScreen();
            await Task.Delay(120000);
            this.Close();
        }

        private void SetFullScreen()
        {
            IntPtr hWnd = this.Handle;
            int currentStyle = GetWindowLong(hWnd, GWL_STYLE);
            SetWindowLong(hWnd, GWL_STYLE, WS_POPUP | WS_VISIBLE);
            this.Bounds = Screen.PrimaryScreen.Bounds;
            axWindowsMediaPlayer1.Dock = DockStyle.Fill;
        }

        [DllImport("user32.dll")]
        private static extern int SetWindowLong(IntPtr hWnd, int nIndex, uint dwNewLong);

        [DllImport("user32.dll")]
        private static extern int GetWindowLong(IntPtr hWnd, int nIndex);

        private const int GWL_STYLE = -16;
        private const uint WS_POPUP = 0x80000000;
        private const uint WS_VISIBLE = 0x10000000;

        private void frmGame_FormClosed(object sender, FormClosedEventArgs e)
        {
            Cursor.Show();
        }
    }
}