﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Box_Rush
{
    public partial class frmMain : Form
    {

        public frmMain()
        {
            InitializeComponent();
            this.Cursor = new Cursor("Cursor-Default-Enemy.cur");
            this.Icon = new Icon("679821.ico");
        }

        private void btnPlay_MouseEnter(object sender, EventArgs e)
        {
            btnPlay.BackgroundImage = Image.FromFile("orange.png");
        }

        private void btnPlay_MouseLeave(object sender, EventArgs e)
        {
            btnPlay.BackgroundImage = Image.FromFile("nlue.png");
        }

        private void btnCancel_MouseEnter(object sender, EventArgs e)
        {
            btnCancel.BackgroundImage = Image.FromFile("orange.png");
        }

        private void btnCancel_MouseLeave(object sender, EventArgs e)
        {
            btnCancel.BackgroundImage = Image.FromFile("red.png");
        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
            frmGame frmGame = new frmGame();
            frmGame.Owner = this;
            frmGame.ShowDialog();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
